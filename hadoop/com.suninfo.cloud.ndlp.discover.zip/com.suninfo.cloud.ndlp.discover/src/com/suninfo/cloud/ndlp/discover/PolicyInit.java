package com.suninfo.cloud.ndlp.discover;

import java.util.Map;

public interface PolicyInit {

	boolean init_goods_counter_policy(Map policy);
}
