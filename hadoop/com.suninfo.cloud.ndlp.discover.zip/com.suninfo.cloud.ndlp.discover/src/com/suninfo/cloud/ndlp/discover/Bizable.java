package com.suninfo.cloud.ndlp.discover;

import java.util.List;
import java.util.Map;

public interface Bizable {
	public static final long versionID = 1L;
	void ResetDispatcher();
	void closeServer();
	
	// return log
	MyListString discover(MyListString meta_path);
}