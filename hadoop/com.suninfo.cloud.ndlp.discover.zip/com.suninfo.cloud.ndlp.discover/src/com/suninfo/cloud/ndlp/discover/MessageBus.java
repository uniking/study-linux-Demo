package com.suninfo.cloud.ndlp.discover;

import java.util.ArrayList;
import java.util.List;

public class MessageBus {
	public String m_out_file_content;
	public List<String> m_out_regular_words = new ArrayList<String>();
	
	public List<String> m_out_bank_card_16 = new ArrayList<String>();
	public List<String> m_out_bank_card_16_info = new ArrayList<String>();
	public List<String> m_out_bank_card_19 = new ArrayList<String>();
	public List<String> m_out_bank_card_19_info = new ArrayList<String>();
	
	public List<String> m_out_id_card_15 = new ArrayList<String>();
	public List<String> m_out_id_card_15_info = new ArrayList<String>();
	public List<String> m_out_id_card_18 = new ArrayList<String>();
	public List<String> m_out_id_card_18_info = new ArrayList<String>();
	
	public List<String> m_out_phone = new ArrayList<String>();
	public List<String> m_out_phone_info = new ArrayList<String>();

}
