package com.suninfo.cloud.ndlp.discover;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

/*

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairReceiverInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka.KafkaUtils;


import scala.Tuple2;

*/

public class FileDaemon {
	
	public static void main(String[] args) throws Exception
	{		
		/*
 
			SparkConf sparkConf = new SparkConf().setAppName("wzl_JavaKafkaWordCount");
			JavaStreamingContext jssc = new JavaStreamingContext(sparkConf, new Duration(3000));
			JavaPairReceiverInputDStream<String, String> messages = KafkaUtils.createStream(jssc, args[0], args[1], topicMap);
			
			JavaDStream<String> lines = messages.map(new Function<Tuple2<String, String>, String>(){
				@Override
				public String call(Tuple2<String, String> tuple2)
				{
				
					pm.discover(meta_path, log);
				
					return tuple2._2();
				}
			});
		 
		 */
		
		
		SparkConf sparkConf = new SparkConf().setAppName("fdaemond");
		JavaStreamingContext jssc = new JavaStreamingContext(sparkConf, new Duration(3000));
		jssc.checkpoint("hdfs://node1:9000/user/ubt/wzl");
  	  
		JavaDStream<String> jds = jssc.textFileStream("hdfs://node1:9000/user/wzl");
		jds.checkpoint(new Duration(3000));


		JavaDStream<String> line = jds.flatMap(new FlatMapFunction<String, String>() 
		{
			PolicyManager pm;
			boolean bInit=false;

			@Override
			public Iterator<String> call(String s) throws Exception 
			{//s is file's content
				//if(s==null || s.length() == 0)
				//	return null;
				System.out.println(s);
				
				if(!bInit)
				{
					System.out.println("init policy");
					//pm = new PolicyManager();	
					//pm.load_policy("f:\\policy");
					bInit=true;
				}
				
				//String meta_path = new String("f:\\meta\\file.meta");
				//List<Map> log = new ArrayList<Map>();
				//pm.discover(meta_path, log);
				
				
				List<String> Content = new ArrayList<String>();
				Content.add(s);
				return Content.iterator();
			}
		});
		
		if(line != null)
		{
			JavaDStream<Long> cds = line.count();
			if(cds != null)
				cds.print();
		}
		
	    jssc.start();
	    jssc.awaitTermination();
	    jssc.close();


		
		System.out.println("exit 0");
	}

}
