package com.suninfo.cloud.ndlp.discover;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.ipc.ProtocolProxy;
import org.apache.hadoop.ipc.RPC;

public class fdaemond
{
	public static void main(String[] args) throws IOException
	{
		if(args.length < 1)
		{
			System.out.println("RpcClient xxxx");
			return;
		}
		

		ProtocolProxy<Bizable> proxy = RPC.getProtocolProxy(Bizable.class, 1L, new InetSocketAddress("node1",9527), new Configuration());
		
		for(int i=0; i<10; ++i)
		{
		
			MyListString meta_path = new MyListString();
			meta_path.insertString("/user/wzl/file.meta");
			meta_path.insertString("/user/wzl/file2.meta");
			MyListString retLog = proxy.getProxy().discover(meta_path);
			
			List<String> llog = new ArrayList<String>();
			retLog.getString(llog);
			for(String one:llog)
			{
				System.out.println("log:" + one);
			}
		
		}
		//System.out.println("fdaemond exit:" + retLog.getSize());
		//proxy.getProxy().closeServer();
		System.out.println("fdaemond exit");
	}
}
