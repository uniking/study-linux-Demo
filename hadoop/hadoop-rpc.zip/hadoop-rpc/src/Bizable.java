
public interface Bizable {
	public static final long versionID = 1L;
	public String sysHi(String name);
	public int add(int a, int b);
}
