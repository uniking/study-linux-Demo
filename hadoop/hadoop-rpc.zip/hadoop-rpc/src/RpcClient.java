import java.io.IOException;
import java.net.InetSocketAddress;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.ipc.ProtocolProxy;
import org.apache.hadoop.ipc.RPC;

public class RpcClient {
	public static void main(String[] args) throws IOException 
	{
		if(args.length < 1)
		{
			System.out.println("RpcClient xxxx");
			return;
		}
		
		ProtocolProxy<Bizable> proxy = RPC.getProtocolProxy(Bizable.class, 1L, new InetSocketAddress("node2",9527), new Configuration());
		String result =  proxy.getProxy().sysHi(args[0]);
		System.out.println(result);
		
		System.out.println("add 10+11");
		int r = proxy.getProxy().add(10, 11);
		System.out.println("=" + r);
	}
}