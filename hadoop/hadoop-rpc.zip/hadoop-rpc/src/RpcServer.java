import java.io.IOException;

import org.apache.hadoop.HadoopIllegalArgumentException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.ipc.RPC;
import org.apache.hadoop.ipc.Server;

public class RpcServer implements Bizable{
	public String sysHi(String name)
	{
		//do something
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "Hi~" + name;
	}
	
	public int add(int a, int b)
	{
		return a+b;
	}
	
	public static void main(String[] args) throws HadoopIllegalArgumentException, IOException
	{
		Configuration conf = new Configuration();
		Server server = new RPC.Builder(conf).setProtocol(Bizable.class).setInstance(new RpcServer())
				.setBindAddress("node2").setPort(9527).build();
		server.start();
	}
}